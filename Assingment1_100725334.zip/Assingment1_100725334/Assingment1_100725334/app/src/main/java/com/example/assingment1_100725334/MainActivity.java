package com.example.assingment1_100725334;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    public static String name;
    public static String phN;
    public static String add;
    public static String emailadd;
    // creating a variable for our text view..
    public EditText userName;
    public EditText phonenumber ;
    public EditText address ;
    public EditText email ;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing our variables
        userName = (EditText) findViewById(R.id.PersonName);
        phonenumber = (EditText) findViewById(R.id.editTextPhone);
        address = (EditText) findViewById(R.id.PostalAddress);
        email = (EditText) findViewById(R.id.editTextEmailAddress);

    }


    public void nextPage(View view) {


      name = userName.getText().toString();
        phN = phonenumber.getText().toString();
        add = address.getText().toString();
        emailadd = email.getText().toString();
        Intent intent = new Intent(getApplicationContext(),pizzaOrder.class);
        intent.putExtra("Name",name);
        startActivity(intent);
        intent.putExtra("PhoneNumber",phN);
        startActivity(intent);
        intent.putExtra("Address",add);
        startActivity(intent);
        intent.putExtra("Email",emailadd);
        startActivity(intent);

    }
}

