package com.example.assingment1_100725334;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import java.text.DecimalFormat;

public class pizzaOrder extends AppCompatActivity {
    public double button_total = 0.0, final_total = 0.0;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pizza_order);
        Spinner spinner = (Spinner) findViewById(R.id.spinner1);
        ArrayAdapter<CharSequence> adapter;
        adapter = ArrayAdapter.createFromResource(this,
                R.array.toppings_arrays, android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    public void buttonPressed(View view) {
        boolean clicked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.radioButton1:
                if (clicked)
                    button_total = 5.60;
                break;
            case R.id.radioButton2:
                if (clicked)
                    button_total = 7.99;
                break;
            case R.id.radioButton3:
                if (clicked)
                    button_total = 9.50;
                break;
            case R.id.radioButton4:
                if (clicked)
                    button_total = 11.38;
                break;
        }
    }

    public void checkClicked(View view) {
        boolean clicked = ((CheckBox) view).isChecked();


        switch (view.getId()) {
            case R.id.checkBox1:
                if (clicked) {
                    button_total += 5.00;
                }

            case R.id.checkBox2:
                if (clicked) {
                    button_total = button_total + 5.00;
                }
            break;
        }

    }

    public void toppingType(AdapterView<?> parent, View view,
                            int pos, long id) {

      String selected=parent.getItemAtPosition(pos).toString();
      if(selected == "Mushrooms ($5)")
          button_total+=5;
      else if(selected == "Sun dried Tomatoes ($5)")
          button_total+=5;

    }
    public void confirmPage(View view) {
        DecimalFormat df = new DecimalFormat("##.##");
        Intent intent = new Intent(getApplicationContext(),confirmPizza.class);
        String finalPrice = Double.toString(Double.parseDouble(df.format(button_total)));
        intent.putExtra("Total",finalPrice);
        startActivity(intent);
    }
}