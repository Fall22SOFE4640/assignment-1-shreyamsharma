package com.example.assingment1_100725334;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    // creating a variable for our text view..
    public EditText userName;
    public EditText phonenumber ;
    public EditText address ;
    public EditText email ;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // initializing our variables
        userName = (EditText)findViewById(R.id.PersonName);
        phonenumber = (EditText)findViewById(R.id.editTextPhone);
        address = (EditText)findViewById(R.id.PostalAddress);
        email = (EditText) findViewById(R.id.editTextEmailAddress);
    }


    public void nextPage(View view) {
        String name = userName.getText().toString();
        String phN = phonenumber.getText().toString();;
        String add = address.getText().toString();;
        String emailadd = email.getText().toString();;
        
        Intent intent = new Intent(getApplicationContext(), pizzaOrder.class);
        intent.putExtra("Name",name);
        intent.putExtra("PhoneNumber",phN);
        intent.putExtra("Address",add);
        intent.putExtra("Email",emailadd);
        startActivity(intent);

    }
}

