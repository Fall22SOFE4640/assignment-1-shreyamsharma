package com.example.assingment1_100725334;

import static com.example.assingment1_100725334.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;

public class confirmPizza extends AppCompatActivity {

    public TextView finalName;
    public TextView final_phnumber;
    public TextView finalAddress;
    public TextView finalEmail;
    public TextView total_cost;
  //  String name,phN,email,add,cost;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_confirm_pizza);
        finalName = findViewById(R.id.final_name);
        final_phnumber = findViewById(R.id.final_phoneNumber);
        finalAddress = findViewById(id.final_address);
        finalEmail = findViewById(id.final_Email);
        total_cost = findViewById(id.final_price);


       // name = getIntent().getExtras().getString("Name");
        finalName.setText("Name : "+MainActivity.name);

        //phN = getIntent().getExtras().getString("PhoneNumber");
        final_phnumber.setText("Number : "+MainActivity.phN);

       // add = getIntent().getExtras().getString("Address");
        finalAddress.setText("Address : "+MainActivity.add);

       // email = getIntent().getExtras().getString("Email");
        finalEmail.setText("Email : "+MainActivity.emailadd);

        String cost = getIntent().getExtras().getString("Total");
        total_cost.setText("$"+cost);

    }
    public void HomePage(View view) {
        Intent intent = new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
}